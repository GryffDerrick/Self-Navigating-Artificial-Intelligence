﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using MathNet.Numerics.LinearAlgebra;

public class GeneticController : MonoBehaviour
{
    [Header("References")]
    public AI_Controller controller;

    [Header("Controls")]
    public int initialPopulation = 85;
    [Range(0.0f, 1.0f)]
    public float mutationRate = 0.055f;

    //---CROSSOVER---
    //How two parents are combined
    [Header("Crossover Controls")]
    public int bestAISelection = 8;
    public int worstAISelection = 3;
    public int numberToCrossover;

    private List<int> genePool = new List<int>();

    private int naturallySelected;

    private NeuralNetwork[] population;

    [Header("Public View")]
    public int currentGeneration;
    public int currentGenome = 0;

    private void Start()
    {
        CreatePopulation();
    }

    private void CreatePopulation()
    {
        population = new NeuralNetwork[initialPopulation];
        //fill out population randomly
        FillPopulationRandom(population, 0);
        //assign first genome to current AI
        ResetToCurrentGenome();
    }

    private void ResetToCurrentGenome()
    {
        controller.ResetWithNetwork(population[currentGenome]);
    }

    private void FillPopulationRandom(NeuralNetwork[] newPopulation, int startingIndex)
    {
        while (startingIndex < initialPopulation)
        {
            newPopulation[startingIndex] = new NeuralNetwork();
            newPopulation[startingIndex].Initialise(controller.LAYERS, controller.NEURONS);
            startingIndex++;
        }
    }

    //function that when called from an AI_Controller announces the AI Death, its fitness, and what network it's a part of
    public void Kill (float fitness, NeuralNetwork network)
    {
        if ( currentGenome < population.Length -1)
        {
            population[currentGenome].fitness = fitness;
            currentGenome++;
            ResetToCurrentGenome();
        }
        else
        {
            print(" REPOPULATING, Last in generation: " + currentGeneration);
            RePopulate();
        }
    }

    private void RePopulate()
    {
        //clear the gene pool every generation
        genePool.Clear();
        //increment generation
        currentGeneration++;
        naturallySelected = 0;

        // --- SORT BY FITNESS ---
        SortPopulation();

        //create a temporary neural network list from the desired previous neural networks
        NeuralNetwork[] newPopulation = PickBestPopulation();

        //breed genes within the new population together
        Crossover(newPopulation);
        //mutate the new crossed over genes
        Mutate(newPopulation);

        FillPopulationRandom(newPopulation, naturallySelected);

        population = newPopulation;

        currentGenome = 0;
        ResetToCurrentGenome();
    }

    private void Crossover (NeuralNetwork[] newPopulation)
    {
        for (int i = 0; i < numberToCrossover; i+=2)
        {
            int IndexA = i;     //index of first parent
            int IndexB = i + 1; //index of second parent

            if (genePool.Count >= 1)
            {
                for (int j = 0; j < 100; j++)
                {
                    //getting random indexes from the gene pool
                    IndexA = genePool[Random.Range(0, genePool.Count)];
                    IndexB = genePool[Random.Range(0, genePool.Count)];

                    if (IndexA != IndexB)
                    {
                        break;
                    }
                }
            }

            //create two child neural networks
            NeuralNetwork firstChild = new NeuralNetwork();
            NeuralNetwork secondChild = new NeuralNetwork();

            //initialise the neural networks to be the right size
            firstChild.Initialise(controller.LAYERS, controller.NEURONS);
            secondChild.Initialise(controller.LAYERS, controller.NEURONS);

            //reset their fitnesses to 0
            firstChild.fitness = 0;
            secondChild.fitness = 0;

            //--- CROSSOVER METHOD ---
            //--- weights ---
            for (int x = 0; x < firstChild.weights.Count; x++)
            {
                //50% change of doing either statement
                if (Random.Range(0.0f, 1.0f) < 0.5f)
                {
                    firstChild.weights[x] = population[IndexA].weights[x];
                    secondChild.weights[x] = population[IndexB].weights[x];
                }
                else
                {
                    firstChild.weights[x] = population[IndexB].weights[x];
                    secondChild.weights[x] = population[IndexA].weights[x];
                }
            }
            //--- biases ---
            for (int y = 0; y < firstChild.biases.Count; y++)
            {
                //50% change of doing either statement
                if (Random.Range(0.0f, 1.0f) < 0.5f)
                {
                    firstChild.biases[y] = population[IndexA].biases[y];
                    secondChild.biases[y] = population[IndexB].biases[y];
                }
                else
                {
                    secondChild.biases[y] = population[IndexA].biases[y];
                    firstChild.biases[y] = population[IndexB].biases[y];
                }
            }


            //we have to increment naturally selected so it's not overwritten at the end
            newPopulation[naturallySelected] = firstChild;
            naturallySelected++;

            newPopulation[naturallySelected] = secondChild;
            naturallySelected++;

        }
    }

    private void Mutate(NeuralNetwork[] newPopulation)
    {
        //children of what was crossed over is what will be mutated
        for (int i = 0; i < naturallySelected; i++)
        {
            for (int j = 0; j < newPopulation[i].weights.Count; j++)
            {
                //generate a random number and if it's less than the defined mutation rate value
                if (Random.Range(0.0f, 1.0f) < mutationRate)
                {
                    //use the MutateMatrix function to add a mutation to the weight
                    newPopulation[i].weights[j] = MutateMatrix(newPopulation[i].weights[j]);
                }
            }
        }
    }

    Matrix<float> MutateMatrix(Matrix<float> A)
    {
        //rather than picking all of the weights, a random amount is picked
        // divide by 7 can be changed to vary how many is picked
        int randomPoints = Random.Range(1, (A.RowCount * A.ColumnCount) / 7);

        Matrix<float> C = A;

        for (int i = 0; i < randomPoints; i++)
        {
            int randomColumn = Random.Range(1, C.ColumnCount);
            int randomRow = Random.Range(1, C.RowCount);

            C[randomRow, randomColumn] = Mathf.Clamp(C[randomRow, randomColumn] + Random.Range(-1f, 1f), -1f, 1f);
        }

        return C;
    }

    private NeuralNetwork[] PickBestPopulation()
    {
        //set up a temporary neural network list based on the initial population
        NeuralNetwork[] newPopulation = new NeuralNetwork[initialPopulation];

        for (int i = 0; i < bestAISelection; i++)
        {
            //transferring best networks over to the next generation without changing
            //this makes it so that the best AI cannot get worse due to crossover
            newPopulation[naturallySelected] = population[i].InitialiseCopy(controller.LAYERS, controller.NEURONS);
            newPopulation[naturallySelected].fitness = 0;
            naturallySelected++;

            //get the fitness and then multiply by ten
            //how many times this current network will be added to the genePool
            //basically increases likelyhood to survive
            int f = Mathf.RoundToInt(population[i].fitness * 10);
            for (int j = 0; j < f; j++)
            {
                //adding the index of the new population neural network
                genePool.Add(i);
            }
        }

        //inverse loop because its sorted highest to lowest
        for (int i = 0; i < worstAISelection; i++)
        {
            int last = population.Length - 1;
            last -= i;

            int f = Mathf.RoundToInt(population[last].fitness * 10);
            for (int j = 0; j < f; j++)
            {
                //adding the index of the new population neural network
                genePool.Add(last);
            }
        }

        return newPopulation;
    }

    private void SortPopulation()
    {
        // --- BUBBLE SORT ---
        // the worst possible sort, but the quickest to write
        for (int i = 0; i < population.Length; i++)
        {
            for (int j = 0; j < population.Length; j++)
            {
                if (population[i].fitness < population[j].fitness)
                {
                    NeuralNetwork temp = population[i];
                    population[i] = population[j];
                    population[j] = temp;
                }
            }
        }
    }
}
