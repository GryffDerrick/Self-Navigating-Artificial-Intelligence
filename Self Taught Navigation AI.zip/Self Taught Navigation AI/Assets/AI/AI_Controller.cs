﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//every time controller is created, a neural network will appear
[RequireComponent(typeof(NeuralNetwork))]
public class AI_Controller : MonoBehaviour
{
    private Vector3 startPosition, startRotation, targetPosition;

    [Header("AI TARGET")]
    GameObject target;
    GameObject start;

    private NeuralNetwork network;

    //min speed - max speed
    [Range(0.5f, 1f)]
    public float accellerationValue;
    [Range(-0.5f, 0.5f)]
    public float turningValue;

    public float timeSinceSpawn = 0f;

    [Header("Fitness")] //fitness function (score of AI)
    //this is useful because if two cars are tied for the lead this can help decide which is better
    //tweaking the 3 multipliers gives control over AI behaviour
    public float overallFitness;
    //public float distanceMultiplier = 0.5f; //the number on the end is how important the distance is
    public float averageSpeedMultiplier = 1.0f; //the number on the end is how important the speed is
    public float sensorMultiplier = 0.1f; //decides how important it is for AI to stay central
    public float distanceToTargetMultiplier = 2.0f; //how important it is for AI to get close to target
    public float distanceFromStartMultiplier = 2.0f;

    [Header("Network Options")]
    //the more layers and neurons means more nuance to each decision
    //more nuance is more training time
    public int LAYERS = 1;
    public int NEURONS = 10;

    //storing values for use in fitness calculation
    private Vector3 lastPosition;
    private float totalDistanceTravelled;
    private float averageSpeed;

    //distance constant used to make a bigger number the closer to a target the AI is
    private float distanceConstant;
    private float distanceToTarget;
    private float distanceFromStart;

    //setting up the inputs for neural net
    private float aSensor, bSensor, cSensor;
    private int normaliseSensorValueA = 20;
    private int normaliseSensorValueB = 60;
    private int normaliseSensorValueV = 20;

    private Vector3 input;

    private void Awake()
    {
        startPosition = transform.position;
        startRotation = transform.eulerAngles;

        //find the target game object
        target = GameObject.FindGameObjectWithTag("Target");
        //get the transform.position of the game object
        targetPosition = target.transform.position;

        start = GameObject.FindGameObjectWithTag("Start");
        startPosition = start.transform.position;

        network = GetComponent<NeuralNetwork>();
    }

    public void Reset()
    {
        timeSinceSpawn = 0;
        totalDistanceTravelled = 0;
        averageSpeed = 0f;
        lastPosition = startPosition;
        overallFitness = 0f;
        transform.position = startPosition;
        transform.eulerAngles = startRotation;
    }

    public void ResetWithNetwork(NeuralNetwork net)
    {
        network = net;
        Reset();
    }

    private void FixedUpdate()
    {
        InputSensors();
        lastPosition = transform.position;

        //Neural Network Code Here
        (accellerationValue, turningValue) = network.RunNetwork(aSensor, bSensor, cSensor);

        MoveAI(accellerationValue, turningValue);

        timeSinceSpawn += Time.deltaTime;

        CalculateFitness();

        if (Input.GetKeyDown(KeyCode.LeftControl))
        {
            Kill();
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        Kill();
    }

    private void Kill()
    {
        GameObject.FindObjectOfType<GeneticController>().Kill(overallFitness, network);
    }

    private void CalculateFitness()
    {
        totalDistanceTravelled += Vector3.Distance(transform.position, lastPosition);
        //every frame we set last pos to current pos
        //calculate distance between last frame and current frame
        //gives small distance value, and adds up over time
        //distance does not need to be exact, a value just needs to exist to be compared to other AI's
        averageSpeed = totalDistanceTravelled / timeSinceSpawn;

        //gets the distance between the target and the AI
        // the constant allows for inversion
        distanceToTarget = distanceConstant / Vector3.Distance(targetPosition, transform.position);
        distanceFromStart = Vector3.Distance(startPosition, transform.position);

        
        //                          distance * importance                       averagespeed * importance                           averages the censor values * importance
        //overallFitness = (totalDistanceTravelled * distanceMultiplier) + (averageSpeed * averageSpeedMultiplier) + (((aSensor + bSensor + cSensor) / 3) * sensorMultiplier);

        overallFitness = (distanceToTarget * distanceToTargetMultiplier) + (distanceFromStart * distanceFromStartMultiplier) + (averageSpeed * averageSpeedMultiplier) + (((aSensor + bSensor + cSensor) / 3) * sensorMultiplier);

        //--- RESET IF FITNESS IS LOW FOR TOO LONG ---
        //tweak here to discourage staying in a spot and spinning
        if (timeSinceSpawn > 10 && overallFitness < 100)
        {
            Kill();
        }

        //--- RESET IF NETWORK IS TOO GOOD ---
        if (overallFitness >= 1000)
        {
            //--- SAVE WEIGHTS TO FILE HERE ---
            Kill();
        }
    }

    private void InputSensors()
    {
        Vector3 inputA = (transform.forward - transform.right); //results in a 45 degree angle vector to the left of the object
        Vector3 inputB = (transform.forward);                    //results in a foward facing vector
        Vector3 inputC = (transform.forward + transform.right);  //results in a 45 degree angle vector to the right of the object

        // ---- GET LEFT DISTANCE ----
        Ray r = new Ray(transform.position, inputA);
        RaycastHit hit;
        if (Physics.Raycast(r, out hit))
        {
            // this helps when passing the number through the sigmoid function
            // if the number passed in is too high, then the sigmoid will tend towards 1
            aSensor = hit.distance / normaliseSensorValueA; //it is divided by 20 so that the value is normalised (a value between 0 - 1) may need changing for different course
            Debug.DrawLine(r.origin, hit.point, Color.green);
            //print(" Sensor A:  " + aSensor);
        }

        // ---- GET FORWARD DISTANCE ----
        r.direction = inputB;
        if (Physics.Raycast(r, out hit))
        {
            // this helps when passing the number through the sigmoid function
            // if the number passed in is too high, then the sigmoid will tend towards 1
            bSensor = hit.distance / normaliseSensorValueB; //it is divided by 20 so that the value is normalised (a value between 0 - 1) may need changing for different course
            Debug.DrawLine(r.origin, hit.point, Color.green);
            //print(" Sensor B:  " + bSensor);
        }

        // ---- GET RIGHT DISTANCE ----
        r.direction = inputC;
        if (Physics.Raycast(r, out hit))
        {
            // this helps when passing the number through the sigmoid function
            // if the number passed in is too high, then the sigmoid will tend towards 1
            bSensor = hit.distance / normaliseSensorValueV; //it is divided by 20 so that the value is normalised (a value between 0 - 1) may need changing for different course
            Debug.DrawLine(r.origin, hit.point, Color.green);
            //print(" Sensor C:  " + cSensor);
        }
    }

    public void MoveAI(float vertical, float horizontal)
    {
        //--- MOVEMENT ---
                                                                        // 11.4f is the acceleration magnitude
        input = Vector3.Lerp(Vector3.zero, new Vector3(0, 0, vertical * 11.4f), 0.02f); //last value is the rate of Lerp
        input = transform.TransformDirection(input); //TransformDirection converts input to relative local space
        transform.position += input;

        //--- ROTATION ---
                                                 //increment in which to rotate
        transform.eulerAngles += new Vector3(0, (horizontal * 45) * 0.2f, 0); // * 0.2f is to smooth out the rotation

    }
}
