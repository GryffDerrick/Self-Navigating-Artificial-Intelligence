﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using MathNet.Numerics.LinearAlgebra;
using System;

using Random = UnityEngine.Random;

public class NeuralNetwork : MonoBehaviour
{
    //.Build creates a matrix populated with 0
    //giving matrix class dimensions (columns, rows)
    //rows much match the number of inputs
    public Matrix<float> inputLayer = Matrix<float>.Build.Dense(1, 3);

    //we don't know how many columns we want, as we want it to be changeable
    public List<Matrix<float>> hiddenLayers = new List<Matrix<float>>();

    //.Build creates a matrix populated with 0
    //giving matrix class dimensions (columns, rows)
    //rows must match the number of outputs
    public Matrix<float> outputLayer = Matrix<float>.Build.Dense(1, 2);

    //we don't know how many columns we want, as we want it to be changeable
    public List<Matrix<float>> weights = new List<Matrix<float>>();

    //this is how much a particular node shifts the final output of a weighting
    //it offsets the weighting calculation
    public List<float> biases = new List<float>();

    public float fitness;

    public void Initialise (int hiddenLayerCount, int hiddenNeuronCount)
    {
        //clear variables here in case function is called in the middle of simulation
        inputLayer.Clear();
        hiddenLayers.Clear();
        outputLayer.Clear();
        weights.Clear();
        biases.Clear();


        for (int i = 0; i < hiddenLayerCount; i++)
        {
            //generate matrix with the number of neurons passed to the function
            Matrix<float> f = Matrix<float>.Build.Dense(1, hiddenNeuronCount);
            //put hidden layers into a list so it can be looped through
            hiddenLayers.Add(f);

            biases.Add(Random.Range(-1f, 1f));

            // ---- WEIGHTS ----
            //connecting weights from previous layer to the next layer

            // if i == 0 then it's input layer
            if ( i == 0)
            {
                // creates a matrix with 3 columns and a number of rows corresponding the hidden layer counts
                //it is done this way to accomodate the multiplication of a matrix
                // Ma columns = Mb Rows
                Matrix<float> inputToHiddenLayer1 = Matrix<float>.Build.Dense(3, hiddenNeuronCount);
                weights.Add(inputToHiddenLayer1);
            }

            //this is easier as the columns and rows already line up as the hidden layers will have the same size
            Matrix<float> hiddenLayerToHiddenLayer = Matrix<float>.Build.Dense(hiddenNeuronCount, hiddenNeuronCount);
            weights.Add(hiddenLayerToHiddenLayer);
        }

        // hidden layer columns * output layer rows
        Matrix<float> hiddenLayerToOutputLayer = Matrix<float>.Build.Dense(hiddenNeuronCount, 2);
        weights.Add(hiddenLayerToOutputLayer);
        biases.Add(Random.Range(-1f, 1f));

        RandomiseWeights();
        
    }

    public NeuralNetwork InitialiseCopy(int hiddenLayerCount, int hiddenNeuronCount)
    {
        NeuralNetwork n = new NeuralNetwork();

        List<Matrix<float>> newWeights = new List<Matrix<float>>();

        for (int i = 0; i < this.weights.Count; i++)
        {
            Matrix<float> currentWeight = Matrix<float>.Build.Dense(weights[i].RowCount, weights[i].ColumnCount);

            for (int j = 0; j < currentWeight.RowCount; j++)
            {
                for (int k = 0; k < currentWeight.ColumnCount; k++)
                {
                    //just iterating through and copying over the weights
                    currentWeight[j, k] = weights[i][j, k];
                }
            }
            newWeights.Add(currentWeight);
        }

        List<float> newBiases = new List<float>();
        newBiases.AddRange(biases);

        n.weights = newWeights;
        n.biases = newBiases;

        n.InitialiseHidden(hiddenLayerCount, hiddenNeuronCount);

        return n;
    }

    public void InitialiseHidden(int hiddenLayerCount, int hiddenNeuronCount)
    {
        inputLayer.Clear();
        hiddenLayers.Clear();
        outputLayer.Clear();

        for(int i = 0; i < hiddenLayerCount + 1; i++)
        {
            Matrix<float> newHiddenLayer = Matrix<float>.Build.Dense(1, hiddenNeuronCount);
            hiddenLayers.Add(newHiddenLayer);
        }
    }

    public void RandomiseWeights()
    {
        //iterate through the weights
        for (int i = 0; i < weights.Count; i++)
        {
            //double nested loop to iterate through matrix values
            for (int j = 0; j < weights[i].RowCount; j++)
            {
                for (int k = 0; k < weights[i].ColumnCount; k++)
                {
                    //populate current matrix value with random between -1f and 1f
                    weights[i][j, k] = Random.Range(-1f, 1f);
                }
            }
        }
    }

    //notation allows to return two things without creating a struct
    //change (float, float) to a list of floats for expansion
    //and then a list of floats passed through for expansion
    public (float, float) RunNetwork (float a, float b, float c)
    {
        inputLayer[0, 0] = a;
        inputLayer[0, 1] = b;
        inputLayer[0, 2] = c;

        //sigmoid function gives value between 0 and 1
        //Tanh gives value between -1 and 1
        //this is used because output values for turning are between -1 and 1
        //acceleration will use values between 0 and 1
        inputLayer = inputLayer.PointwiseTanh();

        //input layer * first weights + bias
        hiddenLayers[0] = ((inputLayer * weights[0]) + biases[0]).PointwiseTanh();

        //same as above, but it's previous layer multiplied by the weights connecting the next layer
        for (int i = 1; i < hiddenLayers.Count; i++)
        {
            hiddenLayers[i] = ((hiddenLayers[i - 1] * weights[i]) + biases[i]).PointwiseTanh();
        }

        //last hidden layer multiplied by the last weights and then adding the last bias
        outputLayer = ((hiddenLayers[hiddenLayers.Count - 1] * weights[weights.Count - 1]) + biases[biases.Count - 1]).PointwiseTanh();

        //First output is acceleration
        //Second output is steering
        return (Sigmoid(outputLayer[0,0]), (float)Math.Tanh(outputLayer[0,1]));
    }

    private float Sigmoid(float s)
    {
        //returning 1 over 1 + E^-s
        return (1/(1 + Mathf.Exp(-s)));
    }
}
